//
//  peir.cpp
//  OOP Homework Project
//
//  Created by Мирослав Николов on 17.06.15.
//  Copyright (c) 2015 г. Мирослав Николов. All rights reserved.
//

#include "peir.h"
