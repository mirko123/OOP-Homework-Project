#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include <string>
#include <vector>
#include <map>
using namespace std;






int main()
{
//    int size = 10;
//    int array[size];
//    array[0] = 321;
//    array[1] = 322;
//    array[2] = 31;
//    array[3] = 231;
//    array[4] = 52;
//    array[5] = 52;
//    array[6] = 213;
//    array[7] = 476;
//    array[8] = 23;
//    array[9] = 416;
////    for (int i = size - 1; i >= 0; i--)
////    {
////        for (int j = 1; j <= i; j++)
////        {
////            if (array[j-1] > array[j])
////            {
////                int temp = array[j-1];
////                array[j-1] = array[j];
////                array[j] = temp;
////            }
////        }
////    }
//    
//    for (int i = 0; i < size; i++)
//    {
//        for (int j = 1; j <= i; j++)
//        {
//            if (array[j-1] > array[j])
//            {
//                int temp = array[j-1];
//                array[j-1] = array[j];
//                array[j] = temp;
//            }
//        }
//    }
//    
//    for (int i = 0; i < 10; i++)
//    {
//        cout<<array[i] << " ";
//    }
//    cout<<endl;
    
    Game* game = new Game();
//    game->BaseMenu("go in shop");
    game->BaseMenu("go in shop");
    game->BaseMenu("start game");

    
    return 0;
}
