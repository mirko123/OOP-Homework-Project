//#include <iostream>
//#include <string>
//#include <vector>
//#include <map>
//using namespace std;
//
//class Creature
//{
//private:
//    int damage;
//    int defense;
//    int health;
//    int mana;
//    int stamina;
//    int critChance;
//public:
//    Creature(int damage = 0, int defense = 0, int health = 0, int mana = 0, int stamina = 0, int critChance = 0)
//    {
//        SetDamage(damage);
//        SetDefense(defense);
//        SetHealth(health);
//        SetMana(mana);
//        SetStamina(stamina);
//        SetCritChance(critChance);
//    }
//    void SetDamage(int damage)
//    {
//        if (damage < 0) {
//            cout<<"damage need be >= 0"<<endl;
//        }
//        else
//            this->damage = damage;
//    }
//    int GetDamage()
//    {
//        return this->damage;
//    }
//    
//    void SetDefense(int defense)
//    {
//        if (defense < 0) {
//            cout<<"defense need be >= 0"<<endl;
//        }
//        else
//            this->defense = defense;
//    }
//    int GetDefense()
//    {
//        return this->defense;
//    }
//    
//    void SetHealth(int health)
//    {
//        if (health < 0) {
//            cout<<"health need be >= 0"<<endl;
//        }
//        else
//            this->health = health;
//    }
//    int GetHealth()
//    {
//        return this->health;
//    }
//    
//    void SetMana(int mana)
//    {
//        if (mana < 0) {
//            cout<<"mana need be >= 0"<<endl;
//        }
//        else
//            this->mana = mana;
//    }
//    int GetMana()
//    {
//        return this->mana;
//    }
//    
//    void SetStamina(int stamina)
//    {
//        if (stamina < 0) {
//            cout<<"stamina need be >= 0"<<endl;
//        }
//        else
//            this->stamina = stamina;
//    }
//    int GetStamina()
//    {
//        return this->stamina;
//    }
//    void SetCritChance(int critChance)
//    {
//        if (critChance < 0) {
//            cout<<"critChance need be >= 0"<<endl;
//        }
//        else
//            this->critChance = critChance;
//    }
//    int GetCritChance()
//    {
//        return this->critChance;
//    }
//    
//    virtual void Attack() = 0;
//    virtual void Move() = 0;
//};
//
//class Peasant:public Creature
//{
//public:
//    void Attack()
//    {
//        
//    }
//    void Move()
//    {
//        
//    }
//};
//
//class Footman:public Creature
//{
//public:
//    void Attack()
//    {
//        
//    }
//    void Move()
//    {
//        
//    }
//};
//
//class Archer:public Creature
//{
//public:
//    void Attack()
//    {
//        
//    }
//    void Move()
//    {
//        
//    }
//};
//
//class Griffon:public Creature
//{
//public:
//    void Attack()
//    {
//        
//    }
//    void Move()
//    {
//        
//    }
//};
//
//class Hero:public Creature
//{
//public:
//    void Attack()
//    {
//        
//    }
//    void Move()
//    {
//        
//    }
//};
//
//class Player
//{
//private:
//    int gold = 300;
//    vector< pair<Creature*, int> > player;
//public:
//    Player()
//    {
//        
//    }
//};
//
//class Shop
//{
//private:
//    map<Creature*, int> price;
//public:
//    Shop()
//    {
//        price[new Peasant] = 30;
//        price[new Footman] = 90;
//        price[new Archer] = 50;
//        price[new Griffon] = 150;
//    }
//    map<Creature*, int> Units()
//    {
//        return price;
//    }
//    void Buy(Creature* &type, vector< pair<Creature*, int> > &playerUnits, int &playerGold )
//    {
//        if (playerGold >= price[type])
//        {
//            playerGold -= price[type];
//            
//            for (int i = 0; i < playerUnits.size(); i++)
//            {
//                if(playerUnits[i].first == type)
//                {
//                    playerUnits[i].second++;
//                    return;
//                }
//            }
//            pair<Creature*, int> unit(type, 1);
//            playerUnits.push_back(unit);
//        }
//    }
//};
//
//class Game
//{
//private:
//    Player m_player;
//    Player m_enemy;
//public:
//    //    Game()
//    //    {
//    //
//    //    }
//    void StartGame()
//    {
//    }
//    void Shoping()
//    {
//        
//    }
//    void Quit()
//    {
//        
//    }
//    
//};
//
//int main() {
//    return 0;
//}
