#include "Game.h"
#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include "Battlefield.h"
#include <string>
#include <vector>
#include <map>
using namespace std;

bool BestPosition(Battlefield* &field, int &sRow, int &sCol, int &dRow, int &dCol);
Game::Game()
{
    m_player = new Player("Player");
    m_enemy = new Player("Enemy");
}

void Game::PrintUnitsPrice(Shop* &shop)
{
//    int i = 0;
//    for (
//         map<string,int>::iterator it = shop->Units().begin(); it != shop->Units().begin(); it++)
//    {
//        cout << it->first << " => " << it->second << '\n';
////        cout<<shop->Units().size()<<" "<<it<<endl;
//    }
    for(auto elem : shop->Units())
    {
        std::cout << elem.first << " => " << elem.second << "\n";
    }
}

void Game::BaseMenu(string command)
{
    if(command == "start game")
    {
        GameMenu();
    }
    else if (command == "go in shop")
    {
//        cout<<"Name: "<<endl;
//        string player;
//        getline(cin, player);
        ShopMenu();
    }
    else if(command == "out")
    {
        
    }
    
//    StartGame();
  //  Menu();
//    QuitGame();
}


void Game::ShopingUnits(Player* &player, Shop* &shop)
{
    int count;
    int random;
    map<string,int> units = shop->Units();
    
    int enemyGold = player->GetGold();
    int max = enemyGold/units["Griffon"];
    if (1 == Random(0, 1) && enemyGold >= units["Griffon"])
    {
        player->Buy(shop, new Griffon(), 1);
        enemyGold = player->GetGold();
    }
    
    max = enemyGold/units["Footman"];
    random = Random(0, 100);
    count = ((double)(max * random)/100 + 0.5);
    if (count > 0)
    {
        player->Buy(shop, new Footman(), count);
        enemyGold = player->GetGold();
    }
    
    
    max = enemyGold/units["Archer"];
    random = Random(0, 100);
    count = ((double)(max * random)/100 + 0.5);
    if (count > 0)
    {
        player->Buy(shop, new Archer(), count);
        enemyGold = player->GetGold();
    }
    
    max = enemyGold/units["Peasant"];
    player->Buy(shop, new Peasant(), max);
}


//void Game::ShopMenu(Player* &player)
//void Game::ShopMenu(string name)
void Game::ShopMenu()
{
    Shop *shop = new Shop();
    int count;
//    int random;
    
//    map<string,int> units = shop->Units();
    
    
    
    {
//        int enemyGold = m_enemy->GetGold();
//        int max = enemyGold/units["Griffon"];
//        if (1 == Random(0, 1) && enemyGold >= units["Griffon"])
//        {
//            m_enemy->Buy(shop, new Griffon(), 1);
//            enemyGold = m_enemy->GetGold();
//            cout<<1<<endl;
//        }
//        
//        max = enemyGold/units["Footman"];
//        random = Random(0, 100);
//        cout<<"random: "<<random<<endl;
//        count = ((double)(max * random)/100 + 0.5);
//        cout<<"max: "<<max<<endl;
//        cout<<"count: "<<count<<endl;
//        if (count > 0)
//        {
//            m_enemy->Buy(shop, new Footman(), count);
//            enemyGold = m_enemy->GetGold();
//        }
//        
//        max = enemyGold/units["Archer"];
//        m_enemy->Buy(shop, new Archer(), max);
    }
    
    m_enemy->Buy(shop, new Griffon(), 10);
    ShopingUnits(m_enemy, shop);
    
    
    m_player->Buy(shop, new Griffon(), 20);
    
    
    
    ShopingUnits(m_player, shop);
    
    
    
    {
        string name = "Miro";
        cout<<"Name: ";
//        getline(cin, name);
        cout<<name<<" is in shop"<<endl;
        Player* player;
    //    if (name == m_player->GetName())
    //    {
    //        player = m_player;
    //    }
    //    else if (name == m_enemy->GetName())
    //    {
    //        player = m_enemy;
    //    }
        player = m_player;
        string input;
        while (true)
        {
            cout<<"Command for shop:"<<endl;
            getline(cin, input);
            if (input[0] == 'b')//buy
            {
                switch (input[6])
                {
                    case 'a'://peasant
                        count = stoi(input.substr(11));
                        player->Buy(shop, new Peasant(), count);
                        break;
                    case 'c'://archer
                        count = stoi(input.substr(10));
                        player->Buy(shop, new Archer(), count);
                        break;
                    case 'o'://footman
                        count = stoi(input.substr(11));
                        player->Buy(shop, new Footman(), count);
                        break;
                    case 'i'://grifon
                        count = stoi(input.substr(11));
                        player->Buy(shop, new Griffon(), count);
                        break;
                    default:
                        break;
                }
            }
            else if (input[0] == 'p')//print
            {
                PrintUnitsPrice(shop);
            }
            else if (input[0] == 'g')//gold
            {
                cout<<player->GetGold()<<endl;
            }
            else break;
        }
    }
}
void Game::GameMenu()
{
    string input;
    Battlefield* field = new Battlefield(m_player,m_enemy);
    
    int sRow;
    int sCol;
    int dRow;
    int dCol;
    int percent;
    field->Print();
    while (true)
    {
        percent = 100;
        cout<<"Command for game:"<<endl;
        getline(cin, input);
        if (input[0] == 'm')//move
        {
            sRow = (input[6] - '0');
            sCol = (input[8] - '0');
            dRow = (input[12] - '0');
            dCol = (input[14] - '0');
            
            if (input.size() > 16 && input[17] == '%')
            {
                percent = stoi(input.substr(18));
            }
            
            field->Move(sRow, sCol, dRow, dCol, percent);
            
        }
        else if (input[0] == 'a')//atack
        {
            sRow = (input[8] - '0');
            sCol = (input[10] - '0');
            dRow = (input[14] - '0');
            dCol = (input[16] - '0');
            
//            cout<<"8:  "<<input[8]<<endl;
//            cout<<"9:  "<<input[9]<<endl;
//            cout<<"10: "<<input[10]<<endl;
//            cout<<"11: "<<input[11]<<endl;
//            cout<<"12: "<<input[12]<<endl;
//            cout<<"13: "<<input[13]<<endl;
//            cout<<"14: "<<input[14]<<endl;
//            cout<<"15: "<<input[15]<<endl;
//            cout<<"16: "<<input[16]<<endl;
            
//            cout<<sRow<<endl;
//            cout<<sCol<<endl;
//            cout<<dRow<<endl;
//            cout<<dCol<<endl;
            
            
            if (input.size() > 18 && input[19] == '%')
            {
                percent = stoi(input.substr(20));
            }
            
            field->Attack(sRow, sCol, dRow, dCol, percent);
            
        }
        else if (input[0] == 'p') //print
        {
            string fileName = "output.txt";
            field->Print(fileName);
        }
        else if (input[0] == 's')
        {
            break;
        }
        else
        {
            cout<<"error command"<<endl;
        }
        
        if(field->IsLose())
        {
            break;
        }
    }
}






//bool BestPosition(Battlefield* &field, int &sRow, int &sCol, int &dRow, int &dCol)
//{
//    int fRow = dRow;
//    int fCol = dCol;
//    int stamina = field->GetCreature(dRow, dCol)->GetStamina();
//    
//    int distance = 100;
//    
////    int lRow = 0;
////    int lCol = 0;
//    
////    dRow = fRow - 1;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow - 1;
////    dCol = fCol ;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow - 1;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    
////    dRow = lRow;
////    dCol = lCol;
//    
//    bool check = false;
//    
//    for (int row = fRow - stamina; row < fRow + stamina; row++)
//    {
//        if (row >= 0 && row < 10)
//        {
//            for (int col = fCol - stamina; col < fCol + stamina; col++)
//            {
//                if (col >= 0 && col < 10 && !(col == fCol && row == fRow))
//                {
//                    if( field->IsFree(row, col) && distance > field->Distance(sRow, sCol, dRow, dCol) )
//                    {
//                        distance = field->Distance(sRow, sCol, dRow, dCol);
//                        dRow = row;
//                        dCol = col;
//                        check = true;
//                    }
//                }
//            }
//        }
//    }
//    
//    if (!check)
//    {
//        cout<<"cant atack"<<endl;
//    }
//    
//    return check;
//}

