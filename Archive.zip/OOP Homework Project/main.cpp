#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include <string>
#include <vector>
#include <map>
using namespace std;






int main()
{
    
    
//    
//    
//    std::vector<int> vec;
//    
//    vec.push_back(6);
//    vec.push_back(-17);
//    vec.push_back(12);
//    
//    // Deletes the second element (vec[1])
//    cout<<vec.size()<<endl;
//    vec.erase(vec.begin() + 1);
//    cout<<vec.size()<<endl;
//    
//        for (int i = 0; i<vec.size(); i++) {
//            cout<<"v1: "<<vec[i]<<endl;
//        }
//    
//    
//    
//    
//    
    
    
//    vector<int> v1;
//    v1.push_back(1);
//    v1.push_back(2);
//    v1.push_back(3);
//    v1.push_back(4);
//    vector<int> v2 = v1;
//    for (int i = 0; i<v1.size(); i++) {
//        cout<<"v1: "<<v1[i];
//        cout<<"  v2: "<<v2[i]<<endl;
//    }
//    
//    
//    v1[0] = 0;
//    v1[1] = 35;
//    cout<<v1.size()<<endl;
//    v1.erase(std::remove(v1.begin(), v1.end(), 1), v1.end());
//    v2.erase(std::remove(v2.begin(), v2.end(), 1), v2.end());
//    cout<<v1.size()<<endl;
//    cout<<endl;
//    
//    for (int i = 0; i<v1.size(); i++) {
////        if(v1[i] == 35) v1[i].erse
//        cout<<"v1: "<<v1[i];
//        cout<<"  v2: "<<v2[i]<<endl;
//    }

    
    Game* game = new Game();
//    game->BaseMenu("go in shop");
    game->BaseMenu("go in shop");
    game->BaseMenu("start game");

    
    return 0;
}
