//
//  main.cpp
//  Game
//
//  Created by Мирослав Николов on 22.05.15.
//  Copyright (c) 2015 г. Мирослав Николов. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
